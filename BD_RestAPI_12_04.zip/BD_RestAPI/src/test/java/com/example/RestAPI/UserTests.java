package com.example.RestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.RestAPI.controller.UserController;
import com.example.RestAPI.model.UserEntity;
import com.example.RestAPI.service.UserService;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest (classes = {com.example.RestAPI.application.RestApiApplication.class})
class UserTests {

	@Mock
	private UserService userService;

	@InjectMocks
	private UserController userController;

	@Test
	void testObterTodos() {
		List<UserEntity> userList = Arrays.asList(
				new UserEntity("1","User1","user1@example.com"),
				new UserEntity("2","User2","user2@example.com")
		);

		when(userService.obterTodos()).thenReturn(userList);

		List<UserEntity> result = userController.obterTodos();

		assertEquals(userList, result);
	}
	@Test
	void testObterPorId(){
		UserEntity user = new UserEntity("1","User1","user1@example.com");

		when(userService.obterPorId("1")).thenReturn(user);

		UserEntity result = userController.obterPorId("1");

		assertEquals(user, result);

	}
	@Test
	void testInserir(){
		UserEntity newUser = new UserEntity("1","User1","user1@example.com");

		when(userService.inserir(newUser)).thenReturn(newUser);

		UserEntity result = userController.inserir(newUser);

		assertEquals(newUser, result);

	}
	@Test
	void testAtualizar(){
		UserEntity updatedUser = new UserEntity("1","UpdatedUser","updatedser1@example.com");

		when(userService.atualizar("1", updatedUser)).thenReturn(updatedUser);

		UserEntity result = userController.atualizar("1", updatedUser);

		assertEquals(updatedUser, result);

	}
	@Test
	void testExcluir(){
		doNothing().when(userService).excluir("1");
		userController.excluir("1");
		verify(userService, times(1)).excluir("1");
	}

}
